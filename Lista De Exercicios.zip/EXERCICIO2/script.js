let ValorQuilo = document.querySelector("#ValorQuilo");
let QuantidadeQuilos = document.querySelector("#QuantidadeQuilos");
let Resultado = document.querySelector("#Resultado");

function CalcularValor(){
    let var1;
    let var2;
    var1=Number(ValorQuilo.value);
    var2=Number(QuantidadeQuilos.value);

    Resultado.textContent=var1*var2;
}
