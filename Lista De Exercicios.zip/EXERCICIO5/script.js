let Valor1 = document.querySelector("#Valor1");
let Valor2 = document.querySelector("#Valor2");
let Resultado = document.querySelector("#Resultado");


function MaiorValor(){

    let var1=Number(Valor1.value)
    let var2=Number(Valor2.value)

    let maior = var1 > var2 ? var1 : var2;
    Resultado.textContent = maior;

}