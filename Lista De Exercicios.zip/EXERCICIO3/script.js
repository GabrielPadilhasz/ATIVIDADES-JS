let Saldo = document.querySelector("#Saldo");
let Resultado = document.querySelector("#Resultado");

function ReajustarSaldo(){
    
    let var1;
    
    var1=Number(Saldo.value);

    Resultado.textContent=var1 * 1.01;
}
