let Valor1 = document.querySelector("#Valor1");
let Resultado = document.querySelector("#Resultado");

function Verificar() {
    let numero = Number(Valor1.value);
    
    if (numero % 2 !== 0) {
        Resultado.textContent = numero + " impar";
    } else {
        Resultado.textContent = numero + " par";
    }
}
