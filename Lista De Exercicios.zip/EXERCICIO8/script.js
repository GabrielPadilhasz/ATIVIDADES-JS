let Codigo = document.querySelector("#Codigo");
let Resultado = document.querySelector("#Resultado");




function NomeProduto() {
    
    let codigo = Number(Codigo.value);
    
    if (codigo === 1) {
        Resultado.textContent = "Parafuso";
    } else if (codigo === 2) {
        Resultado.textContent = "Porca";
    } else if (codigo === 3) {
        Resultado.textContent = "Prego";
    } else {
        Resultado.textContent = "Diversos";
    }
}

