let Numero1 = document.querySelector("#Numero1");
let Numero2 = document.querySelector("#Numero2");
let Numero3 = document.querySelector("#Numero3");
let ResultadoA = document.querySelector("#ResultadoA");
let ResultadoB = document.querySelector("#ResultadoB");
let ResultadoC = document.querySelector("#ResultadoC");
let ResultadoD = document.querySelector("#ResultadoD");

function CalcularMedias(){

    let var1=Number(Numero1.value)
    let var2=Number(Numero2.value)
    let var3=Number(Numero3.value)

    let mediaA = (var1 + var2 + var3) / 3;
    ResultadoA.textContent = mediaA;

    let mediaB = (var1 * 3 + var2 * 2 + var3 * 5) / (3 + 2 + 5);
    ResultadoB.textContent = mediaB;

    let somaDasMedias = mediaA + mediaB;
    ResultadoC.textContent = somaDasMedias;

    let mediaDasMedias = (mediaA + mediaB) / 2;
    ResultadoD.textContent = mediaDasMedias;
}