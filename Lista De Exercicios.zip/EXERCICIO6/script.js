let Valor1 = document.querySelector("#Valor1");
let Valor2 = document.querySelector("#Valor2");
let Valor3 = document.querySelector("#Valor3");
let Valor4 = document.querySelector("#Valor4");
let Resultado = document.querySelector("#Resultado");

function MaiorValor(){

let var1=Number(Valor1.value)
let var2=Number(Valor2.value)
let var3=Number(Valor3.value)
let var4=Number(Valor4.value)

let menor = var1;
    if (var2 < menor) {
        menor = var2;
    }
    if (var3 < menor) {
        menor = var3;
    }
    if (var4 < menor) {
        menor = var4;
    }

    Resultado.textContent = menor;
}